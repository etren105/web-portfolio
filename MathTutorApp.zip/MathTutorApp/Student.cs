﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTutorApp
{
    class Student
    {

        public string Name { get; set; }
        public string Level { get; set; }
        public int AddAsked { get; set; }
        public int SubAsked { get; set; }
        public int MulAsked { get; set; }
        public int AddCorrect { get; set; }
        public int AddWrong { get; set; }
        public int SubCorrect { get; set; }
        public int SubWrong { get; set; }
        public int MulCorrect { get; set; }
        public int MulWrong { get; set; }



    }
}
