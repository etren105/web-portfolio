﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTutorApp
{
    class MathApp
    {
        static void Main(string[] args)
        { 

            Console.WriteLine("Thank you for choosing the Math Tutor App!\n");
            Console.WriteLine("This application will test your basic mathematic skills in grades K1-5.\n");
            Console.WriteLine("Please provide some basic information about yourself so that " +
                    "we may better tailor this experience for you.\n");
            Console.Write("To start off, please enter your name: ");

            Student myObj = new Student();
            myObj.Name = Console.ReadLine();

            Console.Write("Please enter your grade level (1-5): ");
            myObj.Level = Console.ReadLine();
            Convert.ToInt32(myObj.Level);

            Console.WriteLine("\n" + myObj.Name + ", thank you for using the Math Tutor Application! When you are" +
                " ready, please press any key to continue.");
            Console.ReadLine();
            Console.Clear();

            Instructions(myObj);
            


        }


        static void Instructions(Student myObj)
        {
            string selection;


            Console.WriteLine("Please specify the math skill that you would like to be tested on. \n" +
                "The following options for you to choose from are presented below: \n");

            Console.WriteLine("Addition - Enter 1");
            Console.WriteLine("Subtraction - Enter 2");
            Console.WriteLine("Multiplication - Enter 3");
            Console.WriteLine("Surprise Me - Enter 4");

            Console.Write("\nPlease select one of the 4 options above: ");

            selection = Console.ReadLine();
            Convert.ToInt32(selection);

            Choice(selection, myObj);


        }

        static void Choice(string option, Student myObj)
        {
            char opt = 'c';
            switch (Convert.ToInt32(option))
            {
                case 1:
                    Console.WriteLine(myObj.Name + ", we will be testing you on Addition skills in the K-" + myObj.Level + " grade level.\n");
                    Addition(myObj);
                    opt = Ask();

                    do
                    {
                        Addition(myObj);
                        opt = Ask();
                    } while (opt == 'c');

                    if (opt == 'm')
                    {
                        Console.Clear();
                        Instructions(myObj);
                    }
                    else 
                    {
                        Grade(myObj);
                    }
                break;

                case 2:
                    Console.WriteLine(myObj.Name + ", we will be testing you on Subtraction skills in the K-" + myObj.Level + " grade level.\n");
                    Subtraction(myObj);
                    opt = Ask();

                    do
                    {
                        Subtraction(myObj);
                        opt = Ask();
                    } while (opt == 'c');

                    if (opt == 'm')
                    {
                        Console.Clear();
                        Instructions(myObj);
                    }
                    else 
                    {
                        Grade(myObj);
                    }
                break;

                case 3:
                    Console.WriteLine(myObj.Name + ", we will be testing you on Multiplication skills in the K-" + myObj.Level + " grade level.\n");
                    Multiplication(myObj);
                    opt = Ask();

                    do
                    {
                        Multiplication(myObj);
                        opt = Ask();
                    } while (opt == 'c');

                    if (opt == 'm')
                    {
                        Console.Clear();
                        Instructions(myObj);
                    }
                    else
                    {
                        Grade(myObj);
                    }
                break;

                case 4:
                    Random rnd = new Random();
                    Console.WriteLine(myObj.Name + ", we will be testing you on Random math skills in the K-" + myObj.Level + " grade level.\n");

                    do
                    {
                        int ran = rnd.Next(1, 4);
                        if (ran == 1)
                        {
                            Addition(myObj);
                            opt = Ask();
                        }
                        else if (ran == 2)
                        {
                            Subtraction(myObj);
                            opt = Ask();
                        }
                        else if (ran == 3)
                        {
                            Multiplication(myObj);
                            opt = Ask();
                        }
                    } while (opt == 'c');

                    if (opt == 'm')
                    {
                        Console.Clear();
                        Instructions(myObj);
                    }
                    else
                    {
                        Grade(myObj);
                    }
                break;
            }

        }

        static void Addition(Student myObj)
        {
            string res;
            int x = 0, y = 0, yes = 0;
            Random ran = new Random();

            if (Convert.ToInt32(myObj.Level) == 1)
            {
                x = ran.Next(20);
                y = ran.Next(20);
            }

            else if (Convert.ToInt32(myObj.Level) == 2)
            {
                x = ran.Next(50);
                y = ran.Next(50);
            }

            else if (Convert.ToInt32(myObj.Level) == 3)
            {
                x = ran.Next(75);
                y = ran.Next(75);
            }

            else if (Convert.ToInt32(myObj.Level) == 4)
            {
                x = ran.Next(100);
                y = ran.Next(100);
            }

            else if (Convert.ToInt32(myObj.Level) == 5)
            {
                x = ran.Next(200);
                y = ran.Next(200);
            }

            Console.Write(x + " + " + y + " is equal to: ");
            yes = x + y;
            res = Console.ReadLine();
            Convert.ToString(res);
            if (yes == Convert.ToInt32(res))
            {
                Console.WriteLine("That is correct! :D\n");
                myObj.AddAsked++;
                myObj.AddCorrect++;
            }
            else
            {
                Console.WriteLine("That is incorrect! >:(\n");
                myObj.AddAsked++;
                myObj.AddWrong++;
            }

        }

        static void Subtraction(Student myObj)
        {
            string res;
            int x = 0, y = 0, yes = 0;
            Random ran = new Random();

            if (Convert.ToInt32(myObj.Level) == 1)
            {
                x = ran.Next(16, 21);
                y = ran.Next(16);
            }

            else if (Convert.ToInt32(myObj.Level) == 2)
            {
                x = ran.Next(21, 51);
                y = ran.Next(21);
            }

            else if (Convert.ToInt32(myObj.Level) == 3)
            {
                x = ran.Next(31, 61);
                y = ran.Next(31);
            }

            else if (Convert.ToInt32(myObj.Level) == 4)
            {
                x = ran.Next(101, 151);
                y = ran.Next(101);
            }

            else if (Convert.ToInt32(myObj.Level) == 5)
            {
                x = ran.Next(101);
                y = ran.Next(101);
            }

            Console.Write(x + " - " + y + " is equal to: ");
            yes = x - y;
            res = Console.ReadLine();
            Convert.ToString(res);
            if (yes == Convert.ToInt32(res))
            {
                Console.WriteLine("That is correct! :D\n");
                myObj.SubAsked++;
                myObj.SubCorrect++;
            }
            else
            {
                Console.WriteLine("That is incorrect! >:(\n");
                myObj.SubAsked++;
                myObj.SubWrong++;
            }

        }

        static void Multiplication(Student myObj)
        {
            string res;
            int x = 0, y = 0, yes = 0;
            Random ran = new Random();

            if (Convert.ToInt32(myObj.Level) == 1)
            {
                x = ran.Next(5);
                y = ran.Next(5);
            }

            else if (Convert.ToInt32(myObj.Level) == 2)
            {
                x = ran.Next(10);
                y = ran.Next(5);
            }

            else if (Convert.ToInt32(myObj.Level) == 3)
            {
                x = ran.Next(10);
                y = ran.Next(10);
            }

            else if (Convert.ToInt32(myObj.Level) == 4)
            {
                x = ran.Next(15);
                y = ran.Next(10);
            }

            else if (Convert.ToInt32(myObj.Level) == 5)
            {
                x = ran.Next(20);
                y = ran.Next(10);
            }

            Console.Write(x + " * " + y + " is equal to: ");
            yes = x * y;
            res = Console.ReadLine();
            Convert.ToString(res);
            if (yes == Convert.ToInt32(res))
            {
                Console.WriteLine("That is correct! :D\n");
                myObj.MulAsked++;
                myObj.MulCorrect++;
            }
            else
            {
                Console.WriteLine("That is incorrect! >:(\n");
                myObj.MulAsked++;
                myObj.MulWrong++;
            }
        }
        static char Ask()
        {
            char next = 'c';

            Console.Write("To display another question, please press c. To display the options menu, please press m. To quit and see your score, press any key: ");
            next = Console.ReadKey().KeyChar;
            Console.WriteLine("\n");

            return next;

        }

        static void Grade(Student myObj)
        {
            Console.Clear();
            Console.WriteLine("Name: " + myObj.Name);
            Console.WriteLine("Grade Level: K-" + myObj.Level + "\n");

            Console.WriteLine("Number of addition questions asked: " + myObj.AddAsked);
            Console.WriteLine("Number of addition questions correct: " + myObj.AddCorrect);
            Console.WriteLine("Number of addition questions incorrect: " + myObj.AddWrong + "\n");

            Console.WriteLine("Number of subtraction questions asked: " + myObj.SubAsked);
            Console.WriteLine("Number of subtraction questions correct: " + myObj.SubCorrect);
            Console.WriteLine("Number of subtraction questions incorrect: " + myObj.SubWrong + "\n");

            Console.WriteLine("Number of multiplication questions asked: " + myObj.MulAsked);
            Console.WriteLine("Number of multiplication questions correct: " + myObj.MulCorrect);
            Console.WriteLine("Number of multiplication questions incorrect: " + myObj.MulWrong + "\n");
        }




    }
} 
